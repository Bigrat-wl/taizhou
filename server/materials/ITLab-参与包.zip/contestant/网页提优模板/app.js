﻿(() => {
  'use strict';
  const data = window.RECEPTION_DATA || {};
  const $ = id => document.getElementById(id);
  const esc = value =>
    String(value ?? '').replace(
      /[&<>"']/g,
      c =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c],
    );
  const sections = ['participants', 'tables', 'procurement', 'questions'];
  if (sections.some(key => !Array.isArray(data[key]))) {
    $('error').textContent = '数据格式不完整，请检查 data.js 的四个数组。';
    return;
  }
  const people = data.participants.map(p => ({ ...p }));
  const questions = data.questions.map(q => ({ ...q }));
  const statuses = ['待筛选', '推荐答疑', '暂不采用'];
  // 使用输入快照区分不同数据版本，避免新名单继承旧现场状态。
  let hash = 2166136261;
  for (const char of JSON.stringify(data))
    hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
  const key = `itlab-challenge-v2-${hash >>> 0}`;
  try {
    const saved = JSON.parse(localStorage.getItem(key) || '{}');
    people.forEach(p => {
      const s = saved.people?.[p.student_id];
      if (s) {
        p.signed_in = s.signed_in === true;
        p.drink_collected = s.drink_collected === true;
      }
    });
    questions.forEach(q => {
      const status = saved.questions?.[q.question_id];
      if (statuses.includes(status)) q.status = status;
    });
  } catch (_) {
    $('storage').textContent = '本地状态不可读，当前使用初始状态。';
  }
  function save() {
    try {
      localStorage.setItem(
        key,
        JSON.stringify({
          people: Object.fromEntries(
            people.map(p => [
              p.student_id,
              { signed_in: p.signed_in, drink_collected: p.drink_collected },
            ]),
          ),
          questions: Object.fromEntries(
            questions.map(q => [q.question_id, q.status]),
          ),
        }),
      );
    } catch (_) {
      $('storage').textContent = '浏览器无法保存现场状态，刷新会丢失操作。';
    }
  }
  function table(id, headers, rows) {
    $(id).innerHTML = rows.length
      ? `<table><thead><tr>${headers.map(h => `<th scope="col">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table>`
      : '<p>暂无数据。请先填充 data.js。</p>';
  }
  function render() {
    const signedIn = people.filter(p => p.signed_in).length;
    const drinksCollected = people.filter(p => p.drink_collected).length;
    $('summary').textContent =
      `${people.length} 人 · ${data.tables.length} 桌 · 已签到 ${signedIn} 人 · 已领取 ${drinksCollected} 杯`;
    $('metric-people').textContent = people.length;
    $('metric-tables').textContent = data.tables.length;
    $('metric-signed').textContent = signedIn;
    $('metric-drinks').textContent = drinksCollected;
    const needle = $('search').value.trim().toLowerCase();
    const visible = people.filter(p =>
      [p.name, p.student_id, p.group_name, p.group_id].some(v =>
        String(v).toLowerCase().includes(needle),
      ),
    );
    table(
      'people-table',
      [
        '学号',
        '姓名',
        '学院 / 班级',
        '小组 / 角色',
        '到场 / 协助',
        '饮品 / 温度',
        '桌位',
        '签到',
        '领取',
      ],
      visible.map(p => [
        esc(p.student_id),
        esc(p.name),
        esc(`${p.college} / ${p.class_name}`),
        esc(`${p.group_name} / ${p.role}`),
        esc(`${p.arrival} / ${p.assistance}`),
        esc(`${p.drink_brand} ${p.drink_name} / ${p.temperature}`),
        esc(`${p.table_no}-${p.seat_no}`),
        `<button data-person="${esc(p.student_id)}" data-field="signed_in" aria-pressed="${!!p.signed_in}">${p.signed_in ? '已签到' : '签到'}</button>`,
        `<button data-person="${esc(p.student_id)}" data-field="drink_collected" aria-pressed="${!!p.drink_collected}">${p.drink_collected ? '已领取' : '领取'}</button>`,
      ]),
    );
    table(
      'seats-table',
      ['桌号', '容量', '人数', '空位', '小组', '成员座位'],
      data.tables.map(t =>
        [t.table_no, t.capacity, t.count, t.vacancies, t.groups, t.seats].map(
          esc,
        ),
      ),
    );
    table(
      'drinks-table',
      ['品牌', '饮品', '温度', '采购', '已领取', '未领取'],
      data.procurement.map(d => {
        const sent = people.filter(
          p =>
            p.drink_collected &&
            p.drink_brand === d.brand &&
            p.drink_name === d.name &&
            p.temperature === d.temperature,
        ).length;
        return [
          d.brand,
          d.name,
          d.temperature,
          d.quantity,
          sent,
          d.quantity - sent,
        ].map(esc);
      }),
    );
    $('question-list').innerHTML = questions.length
      ? questions
          .map(
            q =>
              `<article><strong>${esc(q.name)} · ${esc(q.student_id)} · ${esc(q.topic)}</strong><p>${esc(q.content)}</p><label>筛选状态 <select data-question="${esc(q.question_id)}">${statuses.map(s => `<option${s === q.status ? ' selected' : ''}>${esc(s)}</option>`).join('')}</select></label></article>`,
          )
          .join('')
      : '<p>暂无问题。</p>';
  }
  $('search').addEventListener('input', render);
  $('people-table').addEventListener('click', event => {
    const b = event.target.closest('button[data-person]');
    if (!b) return;
    const p = people.find(p => p.student_id === b.dataset.person);
    if (!p || !['signed_in', 'drink_collected'].includes(b.dataset.field))
      return;
    p[b.dataset.field] = !p[b.dataset.field];
    save();
    render();
  });
  $('question-list').addEventListener('change', event => {
    const q = questions.find(
      q => q.question_id === event.target.dataset.question,
    );
    if (q && statuses.includes(event.target.value)) {
      q.status = event.target.value;
      save();
    }
  });
  $('reset').addEventListener('click', () => {
    if (!window.confirm('恢复所有签到、领取和问题筛选的初始状态？')) return;
    people.forEach((p, i) => {
      p.signed_in = data.participants[i].signed_in;
      p.drink_collected = data.participants[i].drink_collected;
    });
    questions.forEach((q, i) => {
      q.status = data.questions[i].status;
    });
    save();
    render();
  });
  render();
})();
