﻿window.RECEPTION_DATA = {
  "participants": [],
  "tables": [],
  "procurement": [],
  "questions": []
};
